# Globalcocinas
Globalcocinas website

"npm install" for node dependencies

"bower install" for bower dependencies

"npm start" to run the server
